# OSJ Mini Mall — Buyer Storefront

This is Phase 1 of the OSJ Mini Mall project.

## Current frontend features
- Mobile-first shopping storefront
- Red/gray OSJ branding
- Light/dark mode
- Search and category filtering
- Product details
- Cart with individual item selection
- Quantity controls
- Account sign-up/login demo using local browser storage
- Delivery address fields
- Browser GPS permission
- 10% negotiation floor
- ₦12,800 minimum / ₦2,000,000 maximum order validation
- In-Stock and Pre-Order labels

## Important
This phase is a frontend prototype. It does NOT yet process real payments or store customer data securely.

The next phases should add:
1. Backend/API
2. Database
3. Secure authentication
4. Admin dashboard
5. Product/image upload
6. Paystack payment verification
7. Real order/escrow logic
8. Wallet/deposit system
9. Real buyer/seller negotiation chat
10. Render deployment and PWA conversion

## How to test
Open `index.html` in a browser. On GitHub/Render, publish the repository as a static site for this first frontend test.
